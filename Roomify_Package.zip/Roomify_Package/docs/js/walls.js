var DEFAULT_WALL_COLOR = '#f1efe9';
var WALL_COLOR_PRESETS = [
  '#f1efe9', '#ffffff', '#e7e2d8', '#d8cfc0', '#c9d6c9',
  '#b9c6d9', '#d9b8a3', '#cbb8d8', '#9ca3af', '#33415c'
];

var wallOutline = new THREE.LineSegments(
  new THREE.EdgesGeometry(new THREE.BoxGeometry(0.01, 0.01, 0.01)),
  new THREE.LineBasicMaterial({ color: 0x4f46e5 })
);
wallOutline.visible = false;
scene.add(wallOutline);

function selectWallByIndex(index){
  var wall = walls.find(function(w){ return w.userData.wallIndex === index; });
  if (!wall) return;
  state.selectedWall = wall;

  wallOutline.geometry.dispose();
  wallOutline.geometry = new THREE.EdgesGeometry(wall.geometry);
  wallOutline.position.copy(wall.position);
  wallOutline.rotation.copy(wall.rotation);
  wallOutline.visible = true;

  showWallColorPanel(wall);
}

function deselectWalls(){
  state.selectedWall = null;
  wallOutline.visible = false;
  hideWallColorPanel();
}

function setWallColor(wall, hex){
  wall.material.color.set(hex);
  renderWallSwatchActive(hex);
  saveRoom();
}

function showWallColorPanel(wall){
  var hex = '#' + wall.material.color.getHexString();
  document.getElementById('wall-color-label').textContent = 'Wall ' + wall.userData.wallIndex + ' color';
  document.getElementById('wall-color-custom-input').value = hex;
  renderWallSwatchActive(hex);
  document.getElementById('wall-color-panel').classList.add('visible');
}

function hideWallColorPanel(){
  document.getElementById('wall-color-panel').classList.remove('visible');
}

function renderWallSwatchActive(hex){
  document.querySelectorAll('.wall-swatch').forEach(function(sw){
    sw.classList.toggle('active', sw.dataset.color.toLowerCase() === hex.toLowerCase());
  });
}

function renderWallSwatches(){
  var grid = document.getElementById('wall-swatch-grid');
  grid.innerHTML = '';
  WALL_COLOR_PRESETS.forEach(function(hex){
    var sw = document.createElement('button');
    sw.className = 'wall-swatch';
    sw.style.background = hex;
    sw.dataset.color = hex;
    sw.title = hex;
    sw.addEventListener('click', function(){
      if (state.selectedWall) setWallColor(state.selectedWall, hex);
    });
    grid.appendChild(sw);
  });
}
renderWallSwatches();

document.getElementById('wall-color-custom-input').addEventListener('input', function(e){
  if (state.selectedWall) setWallColor(state.selectedWall, e.target.value);
});

function applyWallColors(colors){
  var valid = colors && colors.length === walls.length;
  walls.forEach(function(wall, i){
    wall.material.color.set(valid ? colors[i] : DEFAULT_WALL_COLOR);
  });
}

function getWallColors(){
  return walls.map(function(w){ return '#' + w.material.color.getHexString(); });
}
