function clearFurniture(){
  state.placedItems.forEach(function(item){ furnitureParent.remove(item.group); });
  state.placedItems = [];
  deselect();
}

function spawnFurniture(catalogId, position, rotationY){
  var data = catalogById(catalogId);
  if (!data) return null;
  var builder = FURNITURE_BUILDERS[catalogId];
  var mesh = builder();
  mesh.position.copy(position || new THREE.Vector3(0, 0, 0));
  mesh.rotation.y = rotationY || 0;
  mesh.userData.isFurniture = true;
  mesh.userData.catalogId = catalogId;
  furnitureParent.add(mesh);
  var item = { group: mesh, catalogId: catalogId, isListed: false, listing: null };
  state.placedItems.push(item);
  return item;
}

function spawnRealFurniture(marketItem, position, rotationY){
  var placeholder = makeBoxMesh(marketItem.width_mm/1000, marketItem.height_mm/1000, marketItem.depth_mm/1000, 0xbfc4cf, {roughness:0.9});
  placeholder.position.y = marketItem.height_mm/2000;

  var g = new THREE.Group();
  g.add(placeholder);
  g.position.copy(position || new THREE.Vector3(0, 0, 0));
  g.rotation.y = rotationY || 0;
  g.userData.isFurniture = true;
  g.userData.catalogId = marketItem.id;
  g.userData.isRealModel = true;
  g.userData.modelLoaded = false;
  furnitureParent.add(g);

  var item = { group: g, catalogId: marketItem.id, isListed: false, listing: null };
  state.placedItems.push(item);

  var url = marketGlbUrl(marketItem);
  if (gltfCache[url]){
    applyRealModel(g, gltfCache[url].clone(true), marketItem, placeholder);
  } else {
    toast('Loading 3D model...', 4000);
    gltfLoader.load(
      url,
      function(gltf){
        gltfCache[url] = gltf.scene;
        applyRealModel(g, gltf.scene.clone(true), marketItem, placeholder);
        toast(marketItem.name.split(' ').slice(0,4).join(' ') + ' loaded', 1600);
      },
      undefined,
      function(err){
        console.warn('Real 3D model failed to load for', marketItem.id, url, err);
        toast('Could not load the real model (network/CORS) -- using a placeholder box', 3000);
        placeholder.material.color.set(0xd8dbe3);
      }
    );
  }
  return item;
}

function applyRealModel(group, model, marketItem, placeholder){
  group.remove(placeholder);
  model.traverse(function(child){
    if (child.isMesh){ child.castShadow = true; child.receiveShadow = true; }
  });

  var box = new THREE.Box3().setFromObject(model);
  var size = new THREE.Vector3(); box.getSize(size);
  var center = new THREE.Vector3(); box.getCenter(center);

  model.position.x -= center.x;
  model.position.z -= center.z;
  model.position.y -= box.min.y;

  var targetW = marketItem.width_mm / 1000, targetH = marketItem.height_mm / 1000, targetD = marketItem.depth_mm / 1000;
  model.scale.set(
    size.x > 0.001 ? targetW / size.x : 1,
    size.y > 0.001 ? targetH / size.y : 1,
    size.z > 0.001 ? targetD / size.z : 1
  );

  group.add(model);
  group.userData.modelLoaded = true;
  updateSelectionRing();
}

function itemFor(group){
  for (var i=0;i<state.placedItems.length;i++) if (state.placedItems[i].group === group) return state.placedItems[i];
  return null;
}

var ringGeo = new THREE.RingGeometry(0.01, 1, 32);
var ringMat = new THREE.MeshBasicMaterial({ color: 0x3b6fe0, transparent:true, opacity:0.55, side: THREE.DoubleSide });
var selectionRing = new THREE.Mesh(ringGeo, ringMat);
selectionRing.rotation.x = -Math.PI/2;
selectionRing.visible = false;
scene.add(selectionRing);

function boundingBoxOf(group){
  return new THREE.Box3().setFromObject(group);
}

function updateSelectionRing(){
  if (!state.selected){ selectionRing.visible = false; return; }
  var box = boundingBoxOf(state.selected);
  var size = new THREE.Vector3(); box.getSize(size);
  var center = new THREE.Vector3(); box.getCenter(center);
  var radius = Math.max(size.x, size.z) * 0.75;
  selectionRing.geometry.dispose();
  selectionRing.geometry = new THREE.RingGeometry(radius*0.82, radius, 32);
  selectionRing.position.set(center.x, box.min.y + 0.01, center.z);
  selectionRing.visible = true;
}

function select(group){
  state.selected = group;
  updateSelectionRing();
  document.getElementById('bottom-toolbar').classList.add('visible');
}

function deselect(){
  state.selected = null;
  state.isMoving = false;
  selectionRing.visible = false;
  document.getElementById('bottom-toolbar').classList.remove('visible');
}

document.querySelectorAll('.wall-btn').forEach(function(btn){
  btn.addEventListener('click', function(){ selectWallByIndex(parseInt(btn.dataset.wall,10)); });
});

var floorPlane = new THREE.Plane(new THREE.Vector3(0,1,0), 0);
var raycaster = new THREE.Raycaster();
var pointerNDC = new THREE.Vector2();

document.getElementById('move-btn').addEventListener('click', function(){
  if (state.selected){
    state.isMoving = true;
    controls.enabled = false;
    moveOriginalPosition = state.selected.position.clone();
  }
});

function isOverlapping(group){
  var box = boundingBoxOf(group);
  box.expandByScalar(-0.02);
  for (var i=0;i<state.placedItems.length;i++){
    var other = state.placedItems[i].group;
    if (other === group) continue;
    var otherBox = boundingBoxOf(other);
    if (box.intersectsBox(otherBox)) return true;
  }
  return false;
}

function flashInvalid(){
  var el = document.getElementById('invalid-flash');
  el.style.background = 'rgba(224,80,59,0.18)';
  setTimeout(function(){ el.style.background = 'rgba(224,80,59,0)'; }, 120);
}

function clampToRoom(v){
  var margin = 0.3;
  v.x = Math.max(-ROOM_W/2+margin, Math.min(ROOM_W/2-margin, v.x));
  v.z = Math.max(-ROOM_D/2+margin, Math.min(ROOM_D/2-margin, v.z));
  return v;
}

document.getElementById('rotate-btn').addEventListener('click', function(){
  if (!state.selected) return;
  animateRotation(state.selected, state.selected.rotation.y, state.selected.rotation.y + Math.PI/4, 220, function(){
    saveRoom();
  });
});

function animateRotation(obj, from, to, duration, onComplete){
  var start = performance.now();
  function tick(now){
    var t = Math.min(1, (now-start)/duration);
    obj.rotation.y = from + (to-from) * easeOutCubic(t);
    updateSelectionRing();
    if (t < 1) requestAnimationFrame(tick);
    else if (onComplete) onComplete();
  }
  requestAnimationFrame(tick);
}
function easeOutCubic(t){ return 1 - Math.pow(1-t, 3); }

document.getElementById('delete-btn').addEventListener('click', function(){
  if (!state.selected) return;
  var group = state.selected;
  var start = performance.now();
  var duration = 150;
  function tick(now){
    var t = Math.min(1, (now-start)/duration);
    var s = 1 - t;
    group.scale.set(s,s,s);
    if (t < 1){ requestAnimationFrame(tick); }
    else {
      furnitureParent.remove(group);
      state.placedItems = state.placedItems.filter(function(it){ return it.group !== group; });
      deselect();
      saveRoom();
      toast('Item deleted');
    }
  }
  requestAnimationFrame(tick);
});

var replaceDrawer = document.getElementById('replace-drawer');
document.getElementById('replace-btn').addEventListener('click', function(){
  if (!state.selected) return;
  var currentItem = itemFor(state.selected);
  if (!currentItem) return;
  var isMarket = isMarketId(currentItem.catalogId);
  var currentData = findCatalogEntry(currentItem.catalogId);
  var grid = document.getElementById('replace-grid');
  grid.innerHTML = '';

  function doReplace(spawnFn, arg, label){
    var pos = state.selected.position.clone();
    var rot = state.selected.rotation.y;
    furnitureParent.remove(state.selected);
    state.placedItems = state.placedItems.filter(function(it){ return it.group !== state.selected; });
    var replacement = spawnFn(arg, pos, rot);
    select(replacement.group);
    replaceDrawer.classList.remove('open');
    saveRoom();
    toast('Replaced with ' + label);
  }

  if (isMarket){
    MARKET_CATALOG.filter(function(c){ return c.category === currentData.category && c.id !== currentData.id; }).forEach(function(c){
      var card = document.createElement('div');
      card.className = 'item-card';
      card.innerHTML = '<img class="item-thumb" loading="lazy" src="'+marketThumb(c)+'" onerror="this.style.opacity=0.15">'+
        '<div class="item-name">'+c.name+'</div><div class="item-price">$'+c.price+'</div>';
      card.addEventListener('click', function(){ doReplace(spawnRealFurniture, c, c.name); });
      grid.appendChild(card);
    });
  } else {
    CATALOG.filter(function(c){ return c.category === currentData.category && c.id !== currentData.id; }).forEach(function(c){
      var card = document.createElement('div');
      card.className = 'item-card';
      card.innerHTML = '<div class="item-icon">'+c.icon+'</div><div class="item-name">'+c.name+'</div><div class="item-price">$'+c.price+'</div>';
      card.addEventListener('click', function(){ doReplace(function(id,pos,rot){ return spawnFurniture(id,pos,rot); }, c.id, c.name); });
      grid.appendChild(card);
    });
  }
  replaceDrawer.classList.add('open');
});
document.getElementById('replace-close-btn').addEventListener('click', function(){ replaceDrawer.classList.remove('open'); });

var sellPanel = document.getElementById('sell-panel');
var sellModalItem = null;

function openSellModal(options){
  options = options || {};
  sellModalItem = options.item || null;
  document.getElementById('sell-title').value = options.title || '';
  document.getElementById('sell-price').value = options.price != null ? options.price : '';
  document.getElementById('sell-condition').value = options.condition || 'Good';
  document.getElementById('sell-description').value = options.description || '';
  var catSelect = document.getElementById('sell-category');
  if (catSelect){
    catSelect.innerHTML = '';
    marketCategories().filter(function(c){ return c !== 'All'; }).forEach(function(c){
      var opt = document.createElement('option');
      opt.value = c;
      opt.textContent = titleCase(c);
      if (c === options.category) opt.selected = true;
      catSelect.appendChild(opt);
    });
  }
  sellPanel.classList.add('visible');
}

document.getElementById('sell-btn').addEventListener('click', function(){
  if (!state.selected) return;
  var item = itemFor(state.selected);
  var data = findCatalogEntry(item.catalogId);
  openSellModal({
    item: item,
    title: data.name,
    price: Math.round(data.price * 0.6),
    condition: 'Good',
    description: 'Gently used ' + data.name.toLowerCase() + '.',
    category: data.category
  });
});
document.getElementById('sell-cancel-btn').addEventListener('click', function(){
  sellPanel.classList.remove('visible');
  sellModalItem = null;
});
document.getElementById('sell-confirm-btn').addEventListener('click', function(){
  var title = document.getElementById('sell-title').value.trim();
  if (!title){ toast('Give it a title first'); return; }
  var price = parseFloat(document.getElementById('sell-price').value) || 0;
  var catSelect = document.getElementById('sell-category');
  var category = catSelect ? catSelect.value : null;

  var item = sellModalItem;
  var data = item ? findCatalogEntry(item.catalogId) : null;
  var isMarket = item ? isMarketId(item.catalogId) : false;

  var listing = {
    id: 'listing_' + Date.now() + '_' + Math.floor(Math.random()*1000),
    title: title,
    price: price,
    condition: document.getElementById('sell-condition').value,
    description: document.getElementById('sell-description').value,
    icon: (data && data.icon) || '\u{1F6CB}️',
    thumb: isMarket ? marketThumb(data) : null,
    category: category || (data && data.category) || null,
    catalogId: isMarket ? item.catalogId : null,
    listedAt: Date.now()
  };

  if (item){
    item.isListed = true;
    item.listing = listing;
  }
  state.marketListings.unshift(listing);
  saveMarket();
  if (item) saveRoom();
  sellPanel.classList.remove('visible');
  sellModalItem = null;
  toast('Listed for $' + price + '!');
});
