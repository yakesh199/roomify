function makeBoxMesh(w,h,d,color,opts){
  opts = opts || {};
  var geo = new THREE.BoxGeometry(w,h,d);
  var mat = new THREE.MeshStandardMaterial({ color: color, roughness: opts.roughness!==undefined?opts.roughness:0.7, metalness: opts.metalness||0 });
  var mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true; mesh.receiveShadow = true;
  return mesh;
}

function group(children, positions){
  var g = new THREE.Group();
  children.forEach(function(child, i){
    if (positions && positions[i]) child.position.set(positions[i][0], positions[i][1], positions[i][2]);
    g.add(child);
  });
  return g;
}

var FURNITURE_BUILDERS = {
  chair: function(){
    var seat = makeBoxMesh(0.45,0.06,0.45,0x8a5a3b);
    var back = makeBoxMesh(0.45,0.5,0.06,0x8a5a3b);
    var legGeo = function(x,z){ var l = makeBoxMesh(0.05,0.42,0.05,0x5c3a22); l.position.set(x,-0.24,z); return l; };
    var g = group([seat, back], [[0,0,0],[0,0.28,-0.2]]);
    [[0.18,0.18],[-0.18,0.18],[0.18,-0.18],[-0.18,-0.18]].forEach(function(p){ g.add(legGeo(p[0],p[1])); });
    g.position.y = 0.45;
    return g;
  },
  sofa: function(){
    var base = makeBoxMesh(1.8,0.4,0.85,0x3d5a99);
    var back = makeBoxMesh(1.8,0.5,0.2,0x334c80);
    var armL = makeBoxMesh(0.2,0.5,0.85,0x334c80);
    var armR = makeBoxMesh(0.2,0.5,0.85,0x334c80);
    var g = group([base,back,armL,armR],[[0,0,0],[0,0.25,-0.32],[-0.8,0.1,0],[0.8,0.1,0]]);
    g.position.y = 0.4;
    return g;
  },
  bed: function(){
    var base = makeBoxMesh(1.6,0.35,2.0,0x6b4a34);
    var mattress = makeBoxMesh(1.5,0.2,1.9,0xe8e2d6);
    var pillow = makeBoxMesh(1.3,0.12,0.35,0xffffff);
    var headboard = makeBoxMesh(1.6,0.7,0.1,0x6b4a34);
    var g = group([base,mattress,pillow,headboard],[[0,0,0],[0,0.28,0],[0,0.4,-0.75],[0,0.5,-0.98]]);
    g.position.y = 0.18;
    return g;
  },
  shelf: function(){
    var sideL = makeBoxMesh(0.05,1.8,0.35,0x8a6239);
    var sideR = makeBoxMesh(0.05,1.8,0.35,0x8a6239);
    var top = makeBoxMesh(0.4,0.05,0.35,0x8a6239);
    var g = group([sideL,sideR,top],[[-0.175,0,0],[0.175,0,0],[0,0.9,0]]);
    for (var i=0;i<4;i++){
      var shelf = makeBoxMesh(0.4,0.04,0.35,0xa9764a);
      shelf.position.set(0, -0.8 + i*0.55, 0);
      g.add(shelf);
    }
    g.position.y = 0.9;
    return g;
  },
  desk: function(){
    var top = makeBoxMesh(1.2,0.06,0.6,0x8a6239);
    var legGeo = function(x,z){ var l = makeBoxMesh(0.06,0.7,0.06,0x5c3a22); l.position.set(x,-0.38,z); return l; };
    var g = group([top],[[0,0,0]]);
    [[0.55,0.25],[-0.55,0.25],[0.55,-0.25],[-0.55,-0.25]].forEach(function(p){ g.add(legGeo(p[0],p[1])); });
    g.position.y = 0.75;
    return g;
  },
  tv: function(){
    var screen = makeBoxMesh(1.0,0.6,0.05,0x111318, {roughness:0.2});
    var stand = makeBoxMesh(0.3,0.05,0.2,0x222222);
    var g = group([screen,stand],[[0,0.3,0],[0,0,0]]);
    g.position.y = 0.05;
    return g;
  },
  tvCabinet: function(){
    var body = makeBoxMesh(1.2,0.5,0.4,0x6b4a34);
    var doorL = makeBoxMesh(0.55,0.4,0.02,0x8a6239);
    var doorR = makeBoxMesh(0.55,0.4,0.02,0x8a6239);
    var g = group([body,doorL,doorR],[[0,0,0],[-0.3,0,0.21],[0.3,0,0.21]]);
    g.position.y = 0.25;
    return g;
  },
  drawerLarge: function(){
    var body = makeBoxMesh(0.7,1.0,0.45,0x7a5638);
    var g = group([body],[[0,0,0]]);
    for (var i=0;i<3;i++){
      var front = makeBoxMesh(0.6,0.28,0.02,0x9a7350);
      front.position.set(0, -0.32 + i*0.32, 0.235);
      var handle = makeBoxMesh(0.12,0.02,0.02,0x2b2b2b);
      handle.position.set(0, -0.32 + i*0.32, 0.25);
      g.add(front); g.add(handle);
    }
    g.position.y = 0.5;
    return g;
  },
  drawerSmall: function(){
    var body = makeBoxMesh(0.5,0.6,0.4,0x7a5638);
    var g = group([body],[[0,0,0]]);
    for (var i=0;i<2;i++){
      var front = makeBoxMesh(0.42,0.24,0.02,0x9a7350);
      front.position.set(0, -0.13 + i*0.26, 0.21);
      g.add(front);
    }
    g.position.y = 0.3;
    return g;
  },
  lamp: function(){
    var base = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.14,0.04,16), new THREE.MeshStandardMaterial({color:0x333333}));
    var pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,0.9,10), new THREE.MeshStandardMaterial({color:0x444444,metalness:0.5,roughness:0.4}));
    var shade = new THREE.Mesh(new THREE.ConeGeometry(0.22,0.28,20,1,true), new THREE.MeshStandardMaterial({color:0xf0e2c0,side:THREE.DoubleSide}));
    pole.castShadow = true; shade.castShadow = true; base.castShadow = true;
    var g = group([base,pole,shade],[[0,0.02,0],[0,0.47,0],[0,0.9,0]]);
    g.position.y = 0;
    return g;
  }
};

var CATALOG = [
  { id:'chair',        name:'Chair',            category:'Seating', price:40, icon:'\u{1FA91}' },
  { id:'sofa',         name:'Sofa',             category:'Seating', price:220, icon:'\u{1F6CB}️' },
  { id:'bed',          name:'Bed',              category:'Bedroom', price:350, icon:'\u{1F6CF}️' },
  { id:'shelf',        name:'Shelf',            category:'Storage', price:65, icon:'\u{1F4DA}' },
  { id:'desk',         name:'Study Desk',       category:'Tables',  price:120, icon:'\u{1FA91}' },
  { id:'tv',           name:'TV',               category:'Decor',   price:300, icon:'\u{1F4FA}' },
  { id:'tvCabinet',    name:'TV Cabinet',       category:'Storage', price:150, icon:'\u{1F5C4}️' },
  { id:'drawerLarge',  name:'Drawer Large',     category:'Storage', price:110, icon:'\u{1F5C4}️' },
  { id:'drawerSmall',  name:'Drawer Small',     category:'Storage', price:70, icon:'\u{1F5C4}️' },
  { id:'lamp',         name:'Lamp',             category:'Decor',   price:30, icon:'\u{1F4A1}' }
];

function catalogById(id){ for (var i=0;i<CATALOG.length;i++) if (CATALOG[i].id===id) return CATALOG[i]; return null; }

function marketThumb(item){
  return 'https://m.media-amazon.com/images/I/' + encodeURIComponent(item.img) + '._AC_SX300_.jpg';
}
function marketGlbUrl(item){
  var shard = item.id.slice(-1);
  return 'https://amazon-berkeley-objects.s3.amazonaws.com/3dmodels/original/' + shard + '/' + item.id + '.glb';
}
function marketById(id){ for (var i=0;i<MARKET_CATALOG.length;i++) if (MARKET_CATALOG[i].id===id) return MARKET_CATALOG[i]; return null; }
function isMarketId(id){ return !!marketById(id); }
function findCatalogEntry(id){ return catalogById(id) || marketById(id); }
function marketCategories(){
  var set = {};
  MARKET_CATALOG.forEach(function(c){ set[c.category] = true; });
  return ['All'].concat(Object.keys(set).sort());
}
function titleCase(s){ return s.charAt(0).toUpperCase() + s.slice(1); }

function escapeHtml(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
    return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
  });
}
