var ROOM_THUMB_ICON =
  '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">' +
    '<path d="M8 22 L32 10 L56 22 L56 52 L8 52 Z" fill="#ffffff" fill-opacity="0.32"/>' +
    '<path d="M8 22 L32 34 L56 22" stroke="#ffffff" stroke-opacity="0.85" stroke-width="2.5" fill="none" stroke-linejoin="round"/>' +
    '<path d="M32 34 L32 52" stroke="#ffffff" stroke-opacity="0.6" stroke-width="2.5"/>' +
  '</svg>';
var ROOM_THUMB_VARIANTS = 6;

function newRoomId(){
  return 'room_' + Date.now() + '_' + Math.floor(Math.random()*1000);
}

function loadAllRooms(){
  var raw = localStorage.getItem(ROOMS_KEY);
  if (raw){
    try { state.rooms = JSON.parse(raw); return; } catch(e){ state.rooms = []; }
  }

  state.rooms = [];
  var legacyRaw = localStorage.getItem(STORAGE_KEY);
  if (legacyRaw){
    try {
      var legacyItems = JSON.parse(legacyRaw);
      if (legacyItems && legacyItems.length){
        state.rooms.push({
          id: newRoomId(),
          name: 'My Room',
          items: legacyItems,
          wallColors: [DEFAULT_WALL_COLOR, DEFAULT_WALL_COLOR, DEFAULT_WALL_COLOR, DEFAULT_WALL_COLOR],
          colorSeed: 0,
          createdAt: Date.now(),
          updatedAt: Date.now()
        });
      }
    } catch(e){}
  }
  saveAllRooms();
}

function saveAllRooms(){
  localStorage.setItem(ROOMS_KEY, JSON.stringify(state.rooms));
}

function getRoom(id){
  for (var i=0;i<state.rooms.length;i++) if (state.rooms[i].id === id) return state.rooms[i];
  return null;
}

function createRoom(name){
  var room = {
    id: newRoomId(),
    name: (name || 'New Room').slice(0, 60),
    items: [],
    wallColors: [DEFAULT_WALL_COLOR, DEFAULT_WALL_COLOR, DEFAULT_WALL_COLOR, DEFAULT_WALL_COLOR],
    colorSeed: state.rooms.length % ROOM_THUMB_VARIANTS,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  state.rooms.push(room);
  saveAllRooms();
  return room;
}

function renameRoom(id, newName){
  var room = getRoom(id);
  if (!room || !newName) return;
  room.name = newName.slice(0, 60);
  saveAllRooms();
}

function deleteRoom(id){
  state.rooms = state.rooms.filter(function(r){ return r.id !== id; });
  if (state.activeRoomId === id) state.activeRoomId = null;
  saveAllRooms();
}

function openRoom(id){
  var room = getRoom(id);
  if (!room) return;
  state.activeRoomId = id;
  loadRoom();
  deselectWalls();
  showScreen('roomEditor');
  updateEditorRoomName();
}

function updateEditorRoomName(){
  var el = document.getElementById('editor-room-name');
  if (!el) return;
  var room = getRoom(state.activeRoomId);
  el.textContent = room ? room.name : 'Untitled Room';
}

var SHOWCASE_SEEDED_KEY = 'roomify_showcase_seeded_v1';

function showcaseRoomTemplate(){
  return {
    id: newRoomId(),
    name: 'Modern Living Room',
    items: [
      { catalogId: 'B07HPQ7HB5', position: [0, 0, -1.34], rotationY: 0, isListed: false, listing: null },
      { catalogId: 'B07DBFT2YG', position: [0, 0, -0.35], rotationY: 0, isListed: false, listing: null },
      { catalogId: 'B07B4M364Y', position: [-1.75, 0, -0.4], rotationY: Math.PI/2, isListed: false, listing: null },
      { catalogId: 'B07B7J5BC2', position: [2.15, 0, 0.6], rotationY: Math.PI/2, isListed: false, listing: null },
      { catalogId: 'B075ZF4S39', position: [2.2, 0, -1.3], rotationY: 0, isListed: false, listing: null },
      { catalogId: 'B0728NWFGY', position: [1.4, 0, -0.35], rotationY: 0, isListed: false, listing: null },
      { catalogId: 'B075X4YDJT', position: [-1.75, 0, 1.3], rotationY: 0, isListed: false, listing: null },
      { catalogId: 'lamp', position: [1.9, 0, 1.7], rotationY: 0, isListed: false, listing: null }
    ],
    wallColors: ['#b9c6d9', '#f1efe9', '#f1efe9', '#f1efe9'],
    colorSeed: 0,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
}

function seedShowcaseRoomIfNeeded(){
  if (localStorage.getItem(SHOWCASE_SEEDED_KEY)) return;
  state.rooms.unshift(showcaseRoomTemplate());
  saveAllRooms();
  localStorage.setItem(SHOWCASE_SEEDED_KEY, 'true');
}

function timeAgo(ts){
  if (!ts) return 'just now';
  var seconds = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (seconds < 45) return 'just now';
  var minutes = Math.floor(seconds / 60);
  if (minutes < 60) return minutes + 'm ago';
  var hours = Math.floor(minutes / 60);
  if (hours < 24) return hours + 'h ago';
  var days = Math.floor(hours / 24);
  if (days < 7) return days + 'd ago';
  var weeks = Math.floor(days / 7);
  if (weeks < 5) return weeks + 'w ago';
  return new Date(ts).toLocaleDateString();
}
