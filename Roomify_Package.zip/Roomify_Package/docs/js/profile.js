function saveProfile(){
  localStorage.setItem(PROFILE_KEY, JSON.stringify(state.profile));
}

function loadProfile(){
  var saved = localStorage.getItem(PROFILE_KEY);
  if (saved){
    try { state.profile = JSON.parse(saved); } catch(e){ state.profile = { name:'', email:'' }; }
  }
  updateAvatarInitial();
}

function updateAvatarInitial(){
  var initial = (state.profile.name || 'G').charAt(0).toUpperCase();
  document.querySelectorAll('.nav-avatar').forEach(function(el){ el.textContent = initial; });
}

function setStat(id, value){
  var el = document.getElementById(id);
  if (el) el.dataset.target = value;
}

function renderProfile(){
  var name = state.profile.name || 'Guest';
  var email = state.profile.email || 'guest@example.com';

  document.getElementById('profile-name').textContent = name;
  document.getElementById('profile-email').textContent = email;
  document.querySelector('.profile-avatar-lg').textContent = name.charAt(0).toUpperCase();
  updateAvatarInitial();

  var totalItems = state.rooms.reduce(function(sum, r){ return sum + r.items.length; }, 0);
  setStat('stat-rooms', state.rooms.length);
  setStat('stat-items', totalItems);
  setStat('stat-listings', state.marketListings.length);

  var list = document.getElementById('profile-listings');
  list.innerHTML = '';
  if (state.marketListings.length === 0){
    list.innerHTML = '<div class="empty-state">Nothing listed yet — sell an item from a room, or use "List a piece" in the Marketplace.</div>';
  } else {
    state.marketListings.forEach(function(listing){
      var row = document.createElement('div');
      row.className = 'listing-row';
      var media = listing.thumb
        ? '<img class="listing-row-thumb" src="'+listing.thumb+'" onerror="this.style.opacity=0.15">'
        : '<div class="listing-row-icon">'+(listing.icon||'\u{1F6CB}️')+'</div>';
      row.innerHTML = media +
        '<div><div class="listing-row-title">'+escapeHtml(listing.title)+'</div>'+
        '<div class="listing-row-meta">Listed '+timeAgo(listing.listedAt || Date.now())+' &middot; '+escapeHtml(listing.condition||'')+'</div></div>'+
        '<div class="listing-row-price">$'+listing.price+'</div>';
      list.appendChild(row);
    });
  }

  animateStatsCountUp();
}

document.getElementById('logout-btn').addEventListener('click', function(){
  showScreen('login');
});
