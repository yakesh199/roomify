window.addEventListener('resize', function(){
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

function updateWallFading(){
  var camDir = new THREE.Vector3(camera.position.x - ROOM_CENTER.x, 0, camera.position.z - ROOM_CENTER.z).normalize();
  walls.forEach(function(wall){
    var normal = new THREE.Vector3(wall.position.x, 0, wall.position.z).normalize();
    var facing = camDir.dot(normal);
    var target = THREE.MathUtils.clamp(1 - facing * 1.35, 0.12, 1);
    wall.material.opacity += (target - wall.material.opacity) * 0.12;
  });
}

function animate(){
  requestAnimationFrame(animate);
  controls.update();
  updateWallFading();
  renderer.render(scene, camera);
}

loadWishlist();
loadPlayerListings();
loadAllRooms();
seedShowcaseRoomIfNeeded();
loadProfile();
initMicroInteractions();
animateLoginIn();
animate();
