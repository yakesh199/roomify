document.getElementById('signup-btn').addEventListener('click', function(){
  var name = document.getElementById('login-name').value.trim() || 'Guest';
  var email = document.getElementById('login-email').value.trim() || 'guest@example.com';
  state.profile = { name: name, email: email };
  saveProfile();
  showScreen('scan');
  runScanSimulation();
});

function runScanSimulation(){
  var steps = ['Detecting walls...', 'Mapping floor space...', 'Recognizing furniture...', 'Building 3D model...', 'Done!'];
  var fill = document.getElementById('scan-fill');
  var status = document.getElementById('scan-status');
  var duration = 3200;
  var start = performance.now();
  fill.style.width = '0%';
  function tick(now){
    var t = Math.min(1, (now-start)/duration);
    fill.style.width = (t*100) + '%';
    var stepIndex = Math.min(steps.length-1, Math.floor(t*(steps.length-1)));
    status.textContent = steps[stepIndex];
    if (t < 1){
      requestAnimationFrame(tick);
    } else {
      setTimeout(function(){ showScreen('home'); renderDashboard(); }, 350);
    }
  }
  requestAnimationFrame(tick);
}

document.querySelectorAll('.nav-link').forEach(function(btn){
  btn.addEventListener('click', function(){
    var target = btn.dataset.nav;
    if (target === 'home'){ showScreen('home'); renderDashboard(); }
    else if (target === 'marketplace'){ goToMarketplace(); }
  });
});

document.getElementById('nav-avatar-btn').addEventListener('click', function(){
  showScreen('profile');
  renderProfile();
});

document.getElementById('brand-logo-btn').addEventListener('click', function(){
  showScreen('home');
  renderDashboard();
});

function goToMarketplace(){
  showScreen('marketplace');
  currentMarketCategory = 'All';
  renderMarketSidebar();
  renderMarketplace();
}

function renderDashboard(){
  var grid = document.getElementById('room-grid');
  grid.innerHTML = '';

  state.rooms.slice().sort(function(a,b){ return b.updatedAt - a.updatedAt; }).forEach(function(room){
    var card = document.createElement('div');
    card.className = 'room-card';
    var count = room.items.length;
    card.innerHTML =
      '<div class="room-card-actions">' +
        '<button class="room-card-icon-btn" data-action="rename" title="Rename">&#9998;</button>' +
        '<button class="room-card-icon-btn" data-action="delete" title="Delete">&#128465;</button>' +
      '</div>' +
      '<div class="room-thumb room-thumb-' + ((room.colorSeed % ROOM_THUMB_VARIANTS) + 1) + '">' + ROOM_THUMB_ICON + '</div>' +
      '<div class="room-card-body">' +
        '<div class="room-card-name">' + escapeHtml(room.name) + '</div>' +
        '<div class="room-card-meta">' + count + ' item' + (count === 1 ? '' : 's') + ' placed &middot; edited ' + timeAgo(room.updatedAt) + '</div>' +
      '</div>';
    card.addEventListener('click', function(){ openRoom(room.id); });
    card.querySelector('[data-action="rename"]').addEventListener('click', function(e){
      e.stopPropagation();
      var name = prompt('Rename room', room.name);
      if (name && name.trim()){ renameRoom(room.id, name.trim()); renderDashboard(); }
    });
    card.querySelector('[data-action="delete"]').addEventListener('click', function(e){
      e.stopPropagation();
      if (confirm('Delete "' + room.name + '"? This can\'t be undone.')){ deleteRoom(room.id); renderDashboard(); }
    });
    grid.appendChild(card);
  });

  var browseCard = document.createElement('div');
  browseCard.className = 'room-card dashed-card';
  browseCard.innerHTML =
    '<div class="dashed-card-icon">&#128715;</div>' +
    '<div class="dashed-card-title">Browse Marketplace</div>' +
    '<div class="dashed-card-sub">Find pieces before you scan</div>';
  browseCard.addEventListener('click', goToMarketplace);
  grid.appendChild(browseCard);

  animateGridIn('#room-grid .room-card');
}

var newRoomModal = document.getElementById('new-room-modal');
document.getElementById('new-room-btn').addEventListener('click', function(){
  document.getElementById('new-room-name-input').value = '';
  animateModalOpen(newRoomModal);
  setTimeout(function(){ document.getElementById('new-room-name-input').focus(); }, 60);
});
document.getElementById('new-room-cancel-btn').addEventListener('click', function(){
  newRoomModal.classList.remove('visible');
});
document.getElementById('new-room-confirm-btn').addEventListener('click', function(){
  var name = document.getElementById('new-room-name-input').value.trim() || 'New Room';
  var room = createRoom(name);
  newRoomModal.classList.remove('visible');
  openRoom(room.id);
});
document.getElementById('new-room-name-input').addEventListener('keydown', function(e){
  if (e.key === 'Enter') document.getElementById('new-room-confirm-btn').click();
});

document.getElementById('back-from-editor-btn').addEventListener('click', function(){
  saveRoom();
  deselect();
  deselectWalls();
  showScreen('home');
  renderDashboard();
});

var catalogDrawer = document.getElementById('catalog-drawer');
var currentCatalogCategory = 'All';

function categories(){
  if (state.catalogSource === 'market') return marketCategories();
  var set = {};
  CATALOG.forEach(function(c){ set[c.category] = true; });
  return ['All'].concat(Object.keys(set));
}

function renderCatalogTabs(){
  var container = document.getElementById('catalog-cat-tabs');
  container.innerHTML = '';
  categories().forEach(function(cat){
    var btn = document.createElement('button');
    btn.className = 'cat-tab' + (cat === currentCatalogCategory ? ' active' : '');
    btn.textContent = state.catalogSource === 'market' && cat !== 'All' ? titleCase(cat) : cat;
    btn.addEventListener('click', function(){ currentCatalogCategory = cat; renderCatalogTabs(); renderCatalogGrid(); });
    container.appendChild(btn);
  });
}

function placeAndStartMoving(placed){
  catalogDrawer.classList.remove('open');
  select(placed.group);
  state.isMoving = true;
  controls.enabled = false;
  moveOriginalPosition = placed.group.position.clone();
  saveRoom();
}

function renderCatalogGrid(){
  var grid = document.getElementById('catalog-grid');
  var query = document.getElementById('catalog-search').value.trim().toLowerCase();
  grid.innerHTML = '';

  if (state.catalogSource === 'market'){
    MARKET_CATALOG.filter(function(item){
      if (currentCatalogCategory !== 'All' && item.category !== currentCatalogCategory) return false;
      if (query && item.name.toLowerCase().indexOf(query) === -1) return false;
      return true;
    }).forEach(function(item){
      var card = document.createElement('div');
      card.className = 'item-card';
      var cm = function(mm){ return Math.round(mm/10); };
      card.innerHTML =
        '<img class="item-thumb" loading="lazy" src="'+marketThumb(item)+'" onerror="this.style.opacity=0.15">'+
        '<div class="item-name">'+escapeHtml(item.name)+'</div>'+
        '<div class="item-brand">'+escapeHtml(item.brand||'')+'</div>'+
        '<div class="item-dims">'+cm(item.width_mm)+'×'+cm(item.depth_mm)+'×'+cm(item.height_mm)+' cm</div>'+
        '<div class="item-price">$'+item.price+'</div>';
      card.addEventListener('click', function(){
        var placed = spawnRealFurniture(item, new THREE.Vector3(0, 0, 0), 0);
        placeAndStartMoving(placed);
      });
      grid.appendChild(card);
    });
    animateGridIn('#catalog-grid .item-card');
    return;
  }

  CATALOG.filter(function(item){
    if (currentCatalogCategory !== 'All' && item.category !== currentCatalogCategory) return false;
    if (query && item.name.toLowerCase().indexOf(query) === -1) return false;
    return true;
  }).forEach(function(item){
    var card = document.createElement('div');
    card.className = 'item-card';
    card.innerHTML = '<div class="item-icon">'+item.icon+'</div><div class="item-name">'+escapeHtml(item.name)+'</div><div class="item-price">$'+item.price+'</div>';
    card.addEventListener('click', function(){
      var placed = spawnFurniture(item.id, new THREE.Vector3(0, 0, 0), 0);
      placeAndStartMoving(placed);
    });
    grid.appendChild(card);
  });
  animateGridIn('#catalog-grid .item-card');
}

document.querySelectorAll('.source-tab').forEach(function(btn){
  btn.addEventListener('click', function(){
    state.catalogSource = btn.dataset.source;
    document.querySelectorAll('.source-tab').forEach(function(b){ b.classList.toggle('active', b === btn); });
    currentCatalogCategory = 'All';
    document.getElementById('catalog-search').value = '';
    renderCatalogTabs();
    renderCatalogGrid();
  });
});

document.getElementById('add-btn').addEventListener('click', function(){
  currentCatalogCategory = 'All';
  document.getElementById('catalog-search').value = '';
  renderCatalogTabs();
  renderCatalogGrid();
  catalogDrawer.classList.add('open');
});
document.getElementById('catalog-close-btn').addEventListener('click', function(){ catalogDrawer.classList.remove('open'); });
document.getElementById('catalog-search').addEventListener('input', renderCatalogGrid);

var browseMarketplaceLink = document.getElementById('browse-marketplace-link');
if (browseMarketplaceLink){
  browseMarketplaceLink.addEventListener('click', function(){
    catalogDrawer.classList.remove('open');
    saveRoom();
    goToMarketplace();
  });
}

var currentMarketCategory = 'All';

function loadPlayerListings(){
  var saved = localStorage.getItem(MARKET_KEY);
  state.marketListings = [];
  if (saved){
    try { state.marketListings = JSON.parse(saved); } catch(e){ state.marketListings = []; }
  }
  var hadLegacySeed = state.marketListings.some(function(l){ return /^seed\d+$/.test(l.id); });
  if (hadLegacySeed){
    state.marketListings = state.marketListings.filter(function(l){ return !/^seed\d+$/.test(l.id); });
    saveMarket();
  }
}

function saveMarket(){
  localStorage.setItem(MARKET_KEY, JSON.stringify(state.marketListings));
}

function realCatalogAsListings(){
  return MARKET_CATALOG.map(function(item){
    return {
      id: 'real_' + item.id,
      catalogId: item.id,
      title: item.name,
      price: item.price,
      condition: 'New',
      description: (item.brand ? item.brand + ' — ' : '') + 'from the Marketplace catalog.',
      thumb: marketThumb(item),
      icon: null,
      category: item.category,
      isReal: true
    };
  });
}

function renderMarketSidebar(){
  var container = document.getElementById('market-sidebar-categories');
  if (!container) return;
  container.innerHTML = '';
  marketCategories().forEach(function(cat){
    var btn = document.createElement('button');
    btn.className = 'sidebar-cat-btn' + (cat === currentMarketCategory ? ' active' : '');
    btn.textContent = cat === 'All' ? cat : titleCase(cat);
    btn.addEventListener('click', function(){ currentMarketCategory = cat; renderMarketSidebar(); renderMarketplace(); });
    container.appendChild(btn);
  });
}

function renderMarketplace(){
  var grid = document.getElementById('market-grid');
  var query = document.getElementById('market-search').value.trim().toLowerCase();
  grid.innerHTML = '';

  var all = state.marketListings.concat(realCatalogAsListings());

  all.filter(function(l){
    if (query && l.title.toLowerCase().indexOf(query) === -1) return false;
    if (currentMarketCategory !== 'All' && l.category && l.category !== currentMarketCategory) return false;
    return true;
  }).forEach(function(listing){
    var card = document.createElement('div');
    card.className = 'mkt-card';
    var wishlisted = !!state.wishlist[listing.id];
    var media = listing.thumb
      ? '<img class="mkt-thumb" loading="lazy" src="'+listing.thumb+'" onerror="this.style.opacity=0.15">'
      : '<div class="mkt-icon">'+(listing.icon||'\u{1F6CB}️')+'</div>';
    card.innerHTML =
      '<button class="heart-btn'+(wishlisted?' active':'')+'">❤</button>'+
      media+
      '<div class="mkt-title">'+escapeHtml(listing.title)+'</div>'+
      '<div class="mkt-price">$'+listing.price+'</div>'+
      '<div class="mkt-condition">'+escapeHtml(listing.condition)+'</div>'+
      (listing.catalogId ? '<button class="btn secondary mkt-add-btn">+ Add to a room</button>' : '');
    card.querySelector('.heart-btn').addEventListener('click', function(e){
      e.stopPropagation();
      state.wishlist[listing.id] = !wishlisted;
      saveWishlist();
      renderMarketplace();
    });
    var addBtn = card.querySelector('.mkt-add-btn');
    if (addBtn){
      addBtn.addEventListener('click', function(e){
        e.stopPropagation();
        addMarketItemToRoom(listing.catalogId);
      });
    }
    grid.appendChild(card);
  });

  animateGridIn('#market-grid .mkt-card');
}
document.getElementById('market-search').addEventListener('input', renderMarketplace);

document.getElementById('list-piece-btn').addEventListener('click', function(){
  var firstRealCategory = marketCategories()[1];
  openSellModal({ item: null, title: '', price: '', condition: 'Good', description: '', category: firstRealCategory });
});

function addMarketItemToRoom(catalogId){
  var item = marketById(catalogId);
  if (!item) return;

  if (!state.activeRoomId){
    if (state.rooms.length > 0){
      var latest = state.rooms.slice().sort(function(a,b){ return b.updatedAt - a.updatedAt; })[0];
      state.activeRoomId = latest.id;
      loadRoom();
    } else {
      var room = createRoom('My Room');
      state.activeRoomId = room.id;
      clearFurniture();
    }
  }

  showScreen('roomEditor');
  updateEditorRoomName();
  var placed = spawnRealFurniture(item, new THREE.Vector3(0, 0, 0), 0);
  select(placed.group);
  state.isMoving = true;
  controls.enabled = false;
  moveOriginalPosition = placed.group.position.clone();
  saveRoom();
  toast('Added to your room — click to drop it in place');
}

function saveWishlist(){
  localStorage.setItem(WISHLIST_KEY, JSON.stringify(state.wishlist));
}
function loadWishlist(){
  var saved = localStorage.getItem(WISHLIST_KEY);
  if (saved){
    try { state.wishlist = JSON.parse(saved); } catch(e){ state.wishlist = {}; }
  }
}
