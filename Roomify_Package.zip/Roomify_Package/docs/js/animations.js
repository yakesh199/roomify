var HAS_GSAP = typeof gsap !== 'undefined';

function animatePageEnter(pageEl){
  if (!HAS_GSAP || !pageEl) return;
  gsap.fromTo(pageEl, { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.4, ease: 'power2.out' });
}

function animateGridIn(selector){
  if (!HAS_GSAP) return;
  var cards = document.querySelectorAll(selector);
  if (!cards.length) return;
  gsap.fromTo(cards, { opacity: 0, y: 14, scale: 0.97 },
    { opacity: 1, y: 0, scale: 1, duration: 0.35, stagger: 0.035, ease: 'power2.out' });
}

function animateModalOpen(panelEl){
  if (!panelEl) return;
  panelEl.classList.add('visible');
  if (!HAS_GSAP) return;
  var box = panelEl.querySelector('.card-box');
  if (!box) return;
  gsap.fromTo(box, { opacity: 0, scale: 0.92, y: 12 }, { opacity: 1, scale: 1, y: 0, duration: 0.4, ease: 'back.out(1.7)' });
}

function animateStatsCountUp(){
  if (!HAS_GSAP){
    document.querySelectorAll('.stat-value[data-target]').forEach(function(el){ el.textContent = el.dataset.target; });
    return;
  }
  document.querySelectorAll('.stat-value[data-target]').forEach(function(el){
    var target = parseInt(el.dataset.target, 10) || 0;
    var counter = { val: 0 };
    gsap.to(counter, {
      val: target, duration: 0.9, ease: 'power1.out',
      onUpdate: function(){ el.textContent = Math.round(counter.val); }
    });
  });
}

function animateToastPop(el){
  if (!HAS_GSAP || !el) return;
  gsap.fromTo(el, { scale: 0.94 }, { scale: 1, duration: 0.3, ease: 'back.out(2.2)' });
}

function initMicroInteractions(){
  if (!HAS_GSAP) return;
  var HOVER_SELECTOR = '.btn, .room-card, .mkt-card, .item-card';
  var PRESS_SELECTOR = '.btn';

  document.addEventListener('mouseenter', function(e){
    var el = e.target.closest && e.target.closest(HOVER_SELECTOR);
    if (!el) return;
    gsap.to(el, { scale: el.classList.contains('btn') ? 1.03 : 1.015, duration: 0.18, ease: 'power2.out', overwrite: 'auto' });
  }, true);

  document.addEventListener('mouseleave', function(e){
    var el = e.target.closest && e.target.closest(HOVER_SELECTOR);
    if (!el) return;
    gsap.to(el, { scale: 1, duration: 0.22, ease: 'power2.out', overwrite: 'auto' });
  }, true);

  document.addEventListener('mousedown', function(e){
    var el = e.target.closest && e.target.closest(PRESS_SELECTOR);
    if (!el) return;
    gsap.to(el, { scale: 0.96, duration: 0.1, ease: 'power2.out', overwrite: 'auto' });
  });

  document.addEventListener('mouseup', function(e){
    var el = e.target.closest && e.target.closest(PRESS_SELECTOR);
    if (!el) return;
    gsap.to(el, { scale: 1.03, duration: 0.15, ease: 'power2.out', overwrite: 'auto' });
  });
}

function animateLoginIn(){
  if (!HAS_GSAP) return;
  var box = document.querySelector('#login-panel .card-box');
  if (!box) return;
  gsap.from(box, { opacity: 0, y: 20, duration: 0.6, ease: 'power2.out' });
}
