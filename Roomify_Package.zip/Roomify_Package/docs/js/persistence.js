function saveRoom(){
  if (!state.activeRoomId) return;
  var room = getRoom(state.activeRoomId);
  if (!room) return;
  room.items = state.placedItems.map(function(item){
    return {
      catalogId: item.catalogId,
      position: item.group.position.toArray(),
      rotationY: item.group.rotation.y,
      isListed: item.isListed,
      listing: item.listing
    };
  });
  room.wallColors = getWallColors();
  room.updatedAt = Date.now();
  saveAllRooms();
}

function loadRoom(){
  clearFurniture();
  var room = getRoom(state.activeRoomId);
  if (!room) return;
  applyWallColors(room.wallColors);
  room.items.forEach(function(saved){
    var pos = new THREE.Vector3(saved.position[0], saved.position[1], saved.position[2]);
    var item;
    if (isMarketId(saved.catalogId)){
      item = spawnRealFurniture(marketById(saved.catalogId), pos, saved.rotationY);
    } else {
      item = spawnFurniture(saved.catalogId, pos, saved.rotationY);
    }
    if (item && saved.isListed){ item.isListed = true; item.listing = saved.listing; }
  });
}

window.addEventListener('beforeunload', function(){
  if (state.screen === 'roomEditor') saveRoom();
});
