var canvas = document.getElementById('scene-canvas');
var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

var scene = new THREE.Scene();
scene.background = new THREE.Color(0xcfd8e8);
scene.fog = new THREE.Fog(0xcfd8e8, 10, 22);

var camera = new THREE.PerspectiveCamera(50, window.innerWidth/window.innerHeight, 0.1, 100);
camera.position.set(0, 3.4, 5.2);

var controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1, 0);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.maxPolarAngle = Math.PI/2 - 0.05;
controls.minDistance = 2.5;
controls.maxDistance = 9;
controls.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.ROTATE };
controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };
controls.update();

var ambient = new THREE.HemisphereLight(0xffffff, 0x555566, 0.7);
scene.add(ambient);
var sun = new THREE.DirectionalLight(0xffffff, 0.9);
sun.position.set(4, 6, 3);
sun.castShadow = true;
sun.shadow.mapSize.set(1024,1024);
sun.shadow.camera.left = -5; sun.shadow.camera.right = 5;
sun.shadow.camera.top = 5; sun.shadow.camera.bottom = -5;
scene.add(sun);

var ROOM_W = 5, ROOM_D = 4, WALL_H = 2.6;
var roomGroup = new THREE.Group();
scene.add(roomGroup);

var floorMat = new THREE.MeshStandardMaterial({ color: 0xe6e1d6, roughness:0.9 });
var floor = new THREE.Mesh(new THREE.PlaneGeometry(ROOM_W, ROOM_D), floorMat);
floor.rotation.x = -Math.PI/2;
floor.receiveShadow = true;
roomGroup.add(floor);

var wallMat = function(){ return new THREE.MeshStandardMaterial({ color: 0xf1efe9, roughness:1, transparent:true, opacity:1 }); };

function makeWall(w, h, d, x, y, z, index){
  var mat = wallMat();
  var mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), mat);
  mesh.position.set(x,y,z);
  mesh.receiveShadow = true;
  mesh.userData.isWall = true;
  mesh.userData.wallIndex = index;
  roomGroup.add(mesh);
  return mesh;
}

var walls = [
  makeWall(ROOM_W, WALL_H, 0.12, 0, WALL_H/2, -ROOM_D/2, 1),
  makeWall(0.12, WALL_H, ROOM_D, -ROOM_W/2, WALL_H/2, 0, 2),
  makeWall(0.12, WALL_H, ROOM_D, ROOM_W/2, WALL_H/2, 0, 3),
  makeWall(ROOM_W, WALL_H, 0.12, 0, WALL_H/2, ROOM_D/2, 4)
];
var ROOM_CENTER = new THREE.Vector3(0, 0, 0);

var furnitureParent = new THREE.Group();
scene.add(furnitureParent);

var gltfLoader = new THREE.GLTFLoader();
var gltfCache = {};

var state = {
  screen: 'login',
  selected: null,
  isMoving: false,
  selectedWall: null,
  placedItems: [],
  rooms: [],
  activeRoomId: null,
  profile: { name: '', email: '' },
  marketListings: [],
  wishlist: {},
  catalogSource: 'market'
};

var STORAGE_KEY = 'room_customizer_save_v1';
var ROOMS_KEY = 'roomify_rooms_v1';
var WISHLIST_KEY = 'room_customizer_wishlist_v1';
var MARKET_KEY = 'room_customizer_market_v1';
var PROFILE_KEY = 'roomify_profile_v1';

var moveOriginalPosition = null;

var overlayPanels = {
  login: document.getElementById('login-panel'),
  scan: document.getElementById('scan-panel'),
  roomEditor: document.getElementById('room-editor-panel')
};
var appShell = document.getElementById('app-shell');
var appPages = {
  home: document.getElementById('home-page'),
  marketplace: document.getElementById('marketplace-page'),
  profile: document.getElementById('profile-page')
};
var APP_SHELL_SCREENS = ['home', 'marketplace', 'profile'];

function showScreen(name){
  state.screen = name;
  var isAppShell = APP_SHELL_SCREENS.indexOf(name) !== -1;

  Object.keys(overlayPanels).forEach(function(key){
    overlayPanels[key].classList.toggle('visible', !isAppShell && key === name);
  });

  if (appShell) appShell.classList.toggle('visible', isAppShell);
  if (isAppShell){
    Object.keys(appPages).forEach(function(key){
      if (appPages[key]) appPages[key].classList.toggle('active', key === name);
    });
    document.querySelectorAll('.nav-link').forEach(function(btn){
      btn.classList.toggle('active', btn.dataset.nav === name);
    });
    if (typeof animatePageEnter === 'function') animatePageEnter(appPages[name]);
  }
}

function toast(msg, duration){
  var el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('visible');
  if (typeof animateToastPop === 'function') animateToastPop(el);
  clearTimeout(toast._t);
  toast._t = setTimeout(function(){ el.classList.remove('visible'); }, duration || 1800);
}
