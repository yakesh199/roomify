function isPointerOverUI(evt){
  var el = document.elementFromPoint(evt.clientX, evt.clientY);
  return el && el !== canvas;
}

function updatePointerNDC(evt){
  pointerNDC.x = (evt.clientX / window.innerWidth) * 2 - 1;
  pointerNDC.y = -(evt.clientY / window.innerHeight) * 2 + 1;
}

canvas.addEventListener('pointerdown', function(evt){
  if (state.screen !== 'roomEditor') return;
  if (evt.button !== 0) return;
  if (isPointerOverUI(evt)) return;

  updatePointerNDC(evt);

  if (state.isMoving && state.selected){
    if (!isOverlapping(state.selected)){
      state.isMoving = false;
      controls.enabled = true;
      resetTint(state.selected);
      saveRoom();
    } else {
      flashInvalid();
    }
    return;
  }

  raycaster.setFromCamera(pointerNDC, camera);
  var furnitureHits = raycaster.intersectObjects(furnitureParent.children, true);
  if (furnitureHits.length > 0){
    var root = furnitureHits[0].object;
    while (root.parent && root.parent !== furnitureParent) root = root.parent;
    select(root);
    deselectWalls();
    return;
  }

  var wallHits = raycaster.intersectObjects(walls, false);
  if (wallHits.length > 0 && wallHits[0].object.visible){
    selectWallByIndex(wallHits[0].object.userData.wallIndex);
    deselect();
    return;
  }

  deselect();
  deselectWalls();
});

canvas.addEventListener('pointermove', function(evt){
  if (state.screen !== 'roomEditor' || !state.isMoving || !state.selected) return;
  updatePointerNDC(evt);
  raycaster.setFromCamera(pointerNDC, camera);
  var hit = new THREE.Vector3();
  if (raycaster.ray.intersectPlane(floorPlane, hit)){
    hit = clampToRoom(hit);
    state.selected.position.x = hit.x;
    state.selected.position.z = hit.z;
    updateSelectionRing();
    tintValidity(state.selected, !isOverlapping(state.selected));
  }
});

canvas.addEventListener('contextmenu', function(evt){
  if (state.isMoving){ evt.preventDefault(); cancelMove(); }
});

window.addEventListener('keydown', function(evt){
  if (evt.key === 'Escape' && state.isMoving){ cancelMove(); }
});

function cancelMove(){
  if (state.selected && moveOriginalPosition){
    state.selected.position.copy(moveOriginalPosition);
    updateSelectionRing();
  }
  state.isMoving = false;
  controls.enabled = true;
  if (state.selected) resetTint(state.selected);
}

function tintValidity(group, valid){
  group.traverse(function(child){
    if (child.isMesh && child.material){
      if (!child.userData._origColor) child.userData._origColor = child.material.color.clone();
      child.material.color.copy(valid ? child.userData._origColor : new THREE.Color(0xe0503b));
    }
  });
}
function resetTint(group){
  group.traverse(function(child){
    if (child.isMesh && child.material && child.userData._origColor){
      child.material.color.copy(child.userData._origColor);
    }
  });
}
