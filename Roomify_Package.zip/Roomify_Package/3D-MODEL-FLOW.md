# How 3D Models Work in Roomify

Quick version, because I know people skim: **our database/backend never stores or serves a single 3D
model file.** The frontend builds the model's URL itself, straight from the item's ID, and fetches it
directly from Amazon's public 3D dataset (ABO). No middleman, no storage bill on our end. Here's exactly
how it happens, file by file, in case future-me (or you) forgets.

## 1. The data

`data/market_catalog.json` holds 229 real furniture items (from the Amazon Berkeley Objects dataset),
each with just metadata — no model file in sight:

```json
{
  "id": "B072ZLCB3M",
  "name": "Amazon Brand – Rivet Bristol Side Table",
  "category": "table",
  "width_mm": 462,
  "depth_mm": 480,
  "height_mm": 480,
  "img": "81Xh+yZvD1L",
  "price": 165
}
```

This gets baked straight into `frontend/RoomCustomizerWeb/js/market-catalog.js` as `MARKET_CATALOG`,
which loads right into the browser. No API call needed just to know what furniture exists.

## 2. Building the model URL

`frontend/RoomCustomizerWeb/js/catalog.js`:

```js
function marketGlbUrl(item){
  var shard = item.id.slice(-1);
  return 'https://amazon-berkeley-objects.s3.amazonaws.com/3dmodels/original/' + shard + '/' + item.id + '.glb';
}
```

We never store the `.glb` path anywhere — it's derived on the fly from the item's `id` (the last
character is the S3 "shard" folder, a little detail that took some digging through ABO's bucket
structure to figure out). This one function is the only place a model "path" gets generated anywhere in
the whole codebase.

## 3. Loading it into the scene

`frontend/RoomCustomizerWeb/js/scene.js`:
```js
var gltfLoader = new THREE.GLTFLoader();
var gltfCache = {}; // url -> loaded model, reused so we don't re-download
```

`frontend/RoomCustomizerWeb/js/furniture.js` (`spawnRealFurniture`) does the rest, step by step:
1. Drops in a correctly-sized placeholder box right away, so the item is selectable and movable
   immediately — nobody should have to wait on a network request just to place something.
2. Calls `marketGlbUrl(marketItem)` to work out the URL.
3. If that URL's already sitting in `gltfCache`, it just reuses the cached model instead of fetching
   again.
4. Otherwise it calls `gltfLoader.load(url, ...)` — this is the actual moment the browser reaches out
   and fetches the `.glb` file directly from Amazon's S3 bucket.
5. On success, the real model swaps in for the placeholder (`applyRealModel`) and gets scaled to the
   item's real `width_mm`/`depth_mm`/`height_mm`, so it actually matches the product's real-world size.
6. On failure (a network hiccup, or CORS being difficult) — the placeholder box just stays put, tinted
   slightly so you can tell something didn't load, but nothing breaks. It quietly degrades instead of
   throwing an error in your face.

`three.js`, `OrbitControls.js`, and `GLTFLoader.js` are all loaded via CDN in `index.html` — they're the
library doing the actual work of parsing `.glb` files, not a source of models themselves.

## 4. Where the backend/database fits in

`backend/load_catalog.py` plus Supabase (`products`, `models` tables) handle a **separate** pipeline
that isn't live yet: matching catalog products to a `model_id` by category and size band, meant for a
proper backend API down the road (`backend/main.py` is still an empty file — no live endpoint exists
yet, it just hasn't been built). None of that touches the frontend flow described above at all — the
two systems don't know about each other yet.

## Key point

There's no "model file" column anywhere, no upload step, no storage bucket that belongs to us. The
frontend just computes the exact public Amazon URL from the product's `id` and lets the browser fetch it
directly. That's genuinely the entire "backend to frontend" path today — simpler than it might sound,
but it works.
